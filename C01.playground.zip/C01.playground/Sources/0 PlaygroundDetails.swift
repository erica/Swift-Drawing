public let chapterFolder = "C01"
public let bookDestination = "/Users/ericasadun/drawing/writing/images/"
