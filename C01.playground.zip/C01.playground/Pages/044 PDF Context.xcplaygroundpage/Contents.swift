import UIKit

// Establish Attributes
func attributeDictionary() -> [String: Any] {
    let style = NSMutableParagraphStyle()
    style.alignment = .left
    style.lineBreakMode = .byWordWrapping
    return [
        NSForegroundColorAttributeName: UIColor.black,
        NSFontAttributeName: UIFont.systemFont(ofSize: 18),
        NSParagraphStyleAttributeName: style
    ]
}
let attributes = attributeDictionary()

// Establish renderer
let size = CGSize(width: 850, height: 1100) // 8.5 x 11 @ 100 dpi
let rect = CGRect(origin: .zero, size: size)
let renderer = UIGraphicsPDFRenderer(bounds: rect)

// Build PDF data
let pdfData = renderer.pdfData { context in
    let drawingRect = rect.insetBy(dx: 100, dy: 100) // 1-inch insets
    
    // Draw three pages of random nonsense
    // To save API calls, all three pages will be identical here
    (1 ... 3).forEach {
        _ in
        context.beginPage()
        let attributedString = NSAttributedString(string: text(), attributes: attributes)
        attributedString.draw(in: drawingRect)
    }
}

// pdfData.savePDFData()


