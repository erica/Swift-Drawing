import Foundation

extension String {
    public var ns: NSString { return self as NSString }
}

extension NSString {
    public var string: String { return self as String }
}

extension String {
    public var firstCapped: String {
        guard !characters.isEmpty else { return self }
        let rest = String(characters.dropFirst())
        let first = String(characters[characters.startIndex]).capitalized
        return first + rest
    }
}
