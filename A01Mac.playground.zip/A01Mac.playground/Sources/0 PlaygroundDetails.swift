public let chapterFolder = "A01"
public let bookDestination = "/Users/ericasadun/drawing/writing/images/"
